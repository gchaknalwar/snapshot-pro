document.getElementById("pngBtn").addEventListener("click", () => {
  chrome.tabs.captureVisibleTab(null, { format: "png" }, function (image) {
    const a = document.createElement("a");
    a.href = image;
    a.download = "screenshot.png";
    a.click();
  });
});

document.getElementById("jpegBtn").addEventListener("click", () => {
  chrome.tabs.captureVisibleTab(null, { format: "jpeg" }, function (image) {
    const a = document.createElement("a");
    a.href = image;
    a.download = "screenshot.jpeg";
    a.click();
  });
});

document.getElementById("pdfBtn").addEventListener("click", () => {
  chrome.tabs.captureVisibleTab(null, { format: "png" }, function (imageUrl) {
    fetch(imageUrl)
      .then(res => res.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = function () {
          const base64data = reader.result.split(',')[1];
          const { jsPDF } = window.jspdf;
          const pdf = new jsPDF();
          pdf.addImage("data:image/png;base64," + base64data, 'PNG', 10, 10, 180, 160);
          const pdfBlob = pdf.output('blob');
          const blobUrl = URL.createObjectURL(pdfBlob);
          chrome.downloads.download({
            url: blobUrl,
            filename: "screenshot.pdf"
          });
        };
        reader.readAsDataURL(blob);
      });
  });
});
