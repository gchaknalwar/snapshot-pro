document.getElementById("pdfBtn").addEventListener("click", async () => {
  chrome.tabs.captureVisibleTab(null, { format: "png" }, (imageUrl) => {
    fetch(imageUrl)
      .then(res => res.blob())
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = function () {
          const base64data = reader.result.split(',')[1];

          const { jsPDF } = window.jspdf;
          const pdf = new jsPDF();
          pdf.addImage("data:image/png;base64," + base64data, 'PNG', 10, 10, 180, 160);

          const pdfBlob = pdf.output('blob');
          const blobUrl = URL.createObjectURL(pdfBlob);

          chrome.downloads.download({
            url: blobUrl,
            filename: "screenshot.pdf"
          });
        };
        reader.readAsDataURL(blob);
      });
  });
});
