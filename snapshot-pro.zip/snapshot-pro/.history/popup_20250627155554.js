async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

document.getElementById("pngBtn").addEventListener("click", async () => {
  chrome.runtime.sendMessage({ action: "capture", format: "png" });
});

document.getElementById("jpegBtn").addEventListener("click", async () => {
  chrome.runtime.sendMessage({ action: "capture", format: "jpeg" });
});

document.getElementById("pdfBtn").addEventListener("click", async () => {
  chrome.runtime.sendMessage({ action: "capture_pdf" });
});
