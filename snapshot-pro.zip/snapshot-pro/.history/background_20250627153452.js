
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "capture") {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, function (screenshotUrl) {
      const a = document.createElement("a");
      a.href = screenshotUrl;
      a.download = "screenshot.png";
      document.body.appendChild(a);
      a.click();
    });
  }
});
