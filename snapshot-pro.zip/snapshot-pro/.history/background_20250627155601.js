chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "capture") {
    chrome.tabs.captureVisibleTab(null, { format: message.format }, (url) => {
      chrome.downloads.download({
        url,
        filename: `screenshot.${message.format}`
      });
    });
  }

  if (message.action === "capture_pdf") {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (imageUrl) => {
      fetch(imageUrl)
        .then(res => res.blob())
        .then(blob => {
          const reader = new FileReader();
          reader.onloadend = function () {
            const base64data = reader.result.split(',')[1];
            const pdf = new jsPDF();
            pdf.addImage(base64data, 'PNG', 10, 10, 180, 160);
            const pdfBlob = pdf.output('blob');

            const blobUrl = URL.createObjectURL(pdfBlob);
            chrome.downloads.download({
              url: blobUrl,
              filename: "screenshot.pdf"
            });
          };
          reader.readAsDataURL(blob);
        });
    });
  }
});
